package com.pampom.mybaties01.mjkutils.reids;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.pampom.mybaties01.mjkutils.util.StrUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;


public class RedisHashUtils {
	public static HashOperations<String, Object, Object> setCacheHash(
			RedisTemplate<String, Object> redisTemplate, String key,
			String index, Object o) {		
		HashOperations<String, Object, Object> hash = redisTemplate.opsForHash();
		hash.put(key, index, o);
		return hash;
	}
	public static void setCacheHash(
			RedisTemplate<String, Object> redisTemplate,final Map<String,Map<String,String>> map) {		
			redisTemplate.execute(new RedisCallback<Integer>() {
			@Override
			public Integer doInRedis(RedisConnection connection)
					throws DataAccessException {
				connection.openPipeline();
				for(Entry<String, Map<String, String>> entry : map.entrySet()){					
					for(Entry<String,String> entry1 : entry.getValue().entrySet()){
						connection.hSet(entry.getKey().getBytes(), entry1.getKey().getBytes(), entry1.getValue().getBytes());
					}
				}
				connection.closePipeline();
				return 0;
			}
		});
	}
	
	
	public static Object getCacheHash(
			RedisTemplate<String, Object> redisTemplate, String key,String index) {
		HashOperations<String, Object, Object> hash = redisTemplate.opsForHash();
		return hash.get(key, index);		
	}

	public static Set<String> getCacheHashList(
			RedisTemplate<String, Object> redisTemplate, String key) {
		HashOperations<String, String, String> hash = redisTemplate.opsForHash();
		return hash.keys(key);		
	}

	
	public static void removeCacheHash(
			RedisTemplate<String, Object> redisTemplate, String key,String index) {
		HashOperations<String, Object, Object> hash = redisTemplate.opsForHash();
		hash.delete(key, index);
	}
	/**
	 * 建中的hash是否存在值
	 * @return
	 */
	public static boolean hashIsExit(RedisTemplate<String, Object> redisTemplate, String key,String index){
		if(StrUtils.isEmpty(getCacheHash(redisTemplate,key,index))){
			return false;
		}
		return true;
	}
}
