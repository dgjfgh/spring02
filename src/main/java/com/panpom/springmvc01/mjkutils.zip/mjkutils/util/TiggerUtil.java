package com.pampom.mybaties01.mjkutils.util;

import org.springframework.jdbc.core.JdbcTemplate;

/**
 * 订单表触发器
 * @author jafe
 * @date 2017年9月8日
 */
public class TiggerUtil {
	/**
	 * 定时器目标表
	 */
	public static String TIGGER_SOURCE_TABLENAME = "flow_orderdetail_slave";
	
	public static String insertTigger=" CREATE TRIGGER %s AFTER INSERT ON %s"
			+" FOR EACH ROW"
			+" begin"
			+" INSERT INTO "+TIGGER_SOURCE_TABLENAME+"  VALUES("
			+" new.id,new.createTime,new.effectTime, new.endTime, new.orderAlais,"
			+" new.outOrderId, new.payAccount, new.payMoney, new.remark, new.status,"
			+" new.validTime, new.channelDiscount,new.userDiscount, new.channelId, "
			+" new.goodsId, new.userId,new.appId);"
			+" end";
	
	public static String updateTigger = "create trigger %s"+
			" after UPDATE on %s"+
			" for each row "+
			" begin"+
			" UPDATE "+TIGGER_SOURCE_TABLENAME+" SET  remark = new.remark, "+
			" status = new.status, endTime = new.endTime WHERE id = old.id;"+
			" end";
	
	public static String delTigger = "create trigger %s"+
			" after DELETE on %s"+
			" for each row "+
			" begin"+
			" DELETE FROM "+TIGGER_SOURCE_TABLENAME+" WHERE id = old.id ;"+
			" end";
	public static String SELECT_TIGGER = "select count(*) from information_schema.triggers where trigger_name = '%S'";
	/**
	 * 创建触发器
	 * @param taggerName 触发器名称
	 * @param taggerTabelName 要触发的表名称
	 * @param sourceTableName  触发之后存入的表名称
	 */
	public static void creteOrderTigger(String tiggerTabelName){
		String tiggerName = tiggerTabelName.replace("flow_", "");
		String selectTigger = "select count(*) from information_schema.triggers where trigger_name = '"+tiggerName+"'";
		JdbcTemplate jdbcTemplate = (JdbcTemplate) SpringBeanUtil.getBean("jdbcTemplate");
		
		Integer size = size = jdbcTemplate.queryForObject(String.format(SELECT_TIGGER, tiggerName), Integer.class);;//jdbcTemplate.queryForInt(String.format(SELECT_TIGGER, tiggerName));
		String sql = String.format(insertTigger, tiggerName,tiggerTabelName);		
		if(size == 0)
			jdbcTemplate.execute(sql);
		String upTiggerName = "up"+tiggerName;
		size = jdbcTemplate.queryForObject(String.format(SELECT_TIGGER, upTiggerName), Integer.class);
//		size = jdbcTemplate.queryForInt(String.format(SELECT_TIGGER, upTiggerName));
		String upSql = String.format(updateTigger, upTiggerName,tiggerTabelName);
		if(size == 0)
			jdbcTemplate.execute(upSql);
		String delTiggerName = "del"+tiggerName;
//		size = jdbcTemplate.queryForInt(String.format(SELECT_TIGGER, delTiggerName));
		size = jdbcTemplate.queryForObject(String.format(SELECT_TIGGER, delTiggerName), Integer.class);
		String delSql = String.format(delTigger, delTiggerName,tiggerTabelName);
		if(size == 0)
			jdbcTemplate.execute(delSql);
	}
}
