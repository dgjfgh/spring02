package com.pampom.mybaties01.mjkutils.util;

import com.pampom.mybaties01.mjkutils.Logger.BizLogger;

import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class StrUtils {
	
	
	/**判断输入对象是否为空，如果为空返回True，否则返回False
	 * @param pObj
	 * @return boolean
	 */
	@SuppressWarnings("rawtypes")
	public static boolean isEmpty(Object pObj) {
		if(pObj == null){
			return true;
		}

		if(pObj instanceof String){
			String str = (String) pObj ;
			str = str.trim();
			if(str.length() == 0)
			{
				return true;
			}
		} else if(pObj instanceof Collection) {
			Collection collection = (Collection) pObj ;
			if(collection.size() == 0)
			{	
				return true;
			}
		}else if(pObj instanceof Map) {
			Map map = (Map) pObj ;
			if(map.size() == 0){
				return true;
			}
		} else if(pObj.getClass().isArray()) {
			int len = Array.getLength(pObj);
			if(len == 0){
				return true;
			}
		}

		return false;
	}

	/**判断输入对象是否不为空，如果不为空返回True，否则False
	 * @param pObj
	 * @return boolean
	 */
	public static boolean isNotEmpty(Object pObj) {
		return !isEmpty(pObj);
	}
	/**
	 * 验证对象是否为空
	 * 
	 * @param obj
	 *            被验证的对象
	 * @param message
	 *            异常信息
	 */
	public static void notNull(Object obj, String message) {
		if (obj == null) {
			throw BizLogger.info(new IllegalArgumentException(message + " must be specified"));
		}
	}
	/**
	 * 判断是否是基本类型及包装类 true:是,false:否
	 * 
	 * @param obj
	 * @return
	 */
	public static boolean isPrimitive(Object obj) {
		if (obj.getClass().isPrimitive())
			return true;
		if (obj instanceof Long || obj instanceof Integer
				|| obj instanceof Float || obj instanceof Boolean
				|| obj instanceof Double)
			return true;
		return false;
	}

	public static void Assert(boolean bool,String message){
		if(bool){
			throw new IllegalArgumentException(message+"is assert");
		}
	}
	/**  
	  * 判断一个类是否为基本数据类型。  
	  * @param clazz 要判断的类。  
	  * @return true 表示为基本数据类型。  
	  */ 
	public static boolean isPrimitiveByString(String clazz)
	 {   
	     return 
	     (   
	         clazz.equals(String.class.getName()) ||   
	         clazz.equals(Integer.class.getName())||   
	         clazz.equals(Byte.class.getName()) ||   
	         clazz.equals(Long.class.getName()) ||   
	         clazz.equals(Double.class.getName()) ||   
	         clazz.equals(Float.class.getName()) ||   
	         clazz.equals(Character.class.getName()) ||   
	         clazz.equals(Short.class.getName()) ||   
	         clazz.equals(BigDecimal.class.getName()) ||   
	         clazz.equals(BigInteger.class.getName()) ||   
	         clazz.equals(Boolean.class.getName())||
	         clazz.equals(long.class.getName())||
	         clazz.equals(byte.class.getName())||
	         clazz.equals(double.class.getName())||
	         clazz.equals(float.class.getName())||
	         clazz.equals(short.class.getName())||
	         clazz.equals(boolean.class.getName())||
	         clazz.endsWith(int.class.getName())
	     );   
	 }
	/**
	 * 判断参数否非空
	 * 
	 * @param obj
	 * @param message
	 * @return
	 */
	public static void isNull(Object obj,String message) {
		if (obj == null) {
			throw BizLogger.info(new IllegalArgumentException(message + " must be specified"));
		}
	}
	/**
	 * 首字符改大写
	 * @param s
	 * @return
	 */
	public static String toUpperCaseFirstOne(String s) {
		notNull(s, "s must not null");
		if (Character.isUpperCase(s.charAt(0)))
			return s;
		else
			return (new StringBuilder())
					.append(Character.toUpperCase(s.charAt(0)))
					.append(s.substring(1)).toString();
	}

	/**
	 * 吧小写字母开头，中间有大写字母的 前面家_ 大写改小写
	 * 
	 * @param str
	 * @return
	 */
	public static String strToLowerCase(String str) {
		StringBuilder sb = new StringBuilder();

		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			if (Character.isUpperCase(c) && i != 0) {
				sb.append("_" + Character.toLowerCase(c));
			} else {
				sb.append(c);
			}
		}
		return sb.toString().toLowerCase();
	}
	/**
	 * 分隔字符串 如果不存在，返回一个数组大小为1的原串
	 * @param propertyName
	 * @param splitfix 分隔符
	 * @return
	 */
	public static String[] split(String propertyName, String splitfix) {
		notNull(propertyName, "stirng mast not null");
		if(propertyName.contains(splitfix)){
			return propertyName.split(splitfix);
		}else{
			return new String[]{propertyName};
		}		
	}
	
	/**
	 * 判断字符串是否为数字
	 * 
	 * @param str
	 * @return
	 */
	public static boolean isNumeric(String str) {
		if (str == null || str.length() == 0) {
			return false;
		}
		for (int i = 0; i < str.length(); i++) {
			if (!Character.isDigit(str.charAt(i))) {
				return false;
			}
		}
		return true;
	}
	
	public static boolean equals(String str1, String str2) {
		return str1 == null ? false : str2 == null ? true : str1.equals(str2);
	}

	public static boolean equalsIgnoreCase(String str1, String str2) {
		return str1 == null ? false : str2 == null ? true : str1.equalsIgnoreCase(str2);
	}

	public static String join(Iterator<?> iterator, String separator) {
		if (iterator == null) {
			return null;
		}
		if (!iterator.hasNext()) {
			return "";
		}
		Object first = iterator.next();
		if (!iterator.hasNext()) {
			return  first == null ? "" : first.toString();
		}
		// two or more elements
		StringBuilder buf = new StringBuilder(256); // Java default is 16,
													// probably too small
		if (first != null) {
			buf.append(first);
		}

		while (iterator.hasNext()) {
			if (separator != null) {
				buf.append(separator);
			}
			Object obj = iterator.next();
			if (obj != null) {
				buf.append(obj);
			}
		}
		return buf.toString();
	}
    public static String join(Iterable<?> iterable, String separator) {
        if (iterable == null) {
            return null;
        }
        return join(iterable.iterator(), separator);
    }
	/**
	 * map to string
	 */
	public static String mapToStr(List<String> map,String separator){
		return join(map, separator);
	}
	
    public static boolean startsWithAny(CharSequence string, CharSequence... searchStrings) {
        if (isEmpty(string) || isEmpty(searchStrings)) {
            return false;
        }
        for (CharSequence searchString : searchStrings) {
            if (startsWith(string, searchString,false)) {
                return true;
            }
        }
        return false;
    }
    
    private static boolean startsWith(CharSequence str, CharSequence prefix, boolean ignoreCase) {
        if (str == null || prefix == null) {
            return str == null && prefix == null;
        }
        if (prefix.length() > str.length()) {
            return false;
        }
        return regionMatches(str, ignoreCase, 0, prefix, 0, prefix.length());
    }
    
    private static boolean regionMatches(CharSequence cs, boolean ignoreCase, int thisStart,
            CharSequence substring, int start, int length)    {
        if (cs instanceof String && substring instanceof String) {
            return ((String) cs).regionMatches(ignoreCase, thisStart, (String) substring, start, length);
        } else {
            // TODO: Implement rather than convert to String
            return cs.toString().regionMatches(ignoreCase, thisStart, substring.toString(), start, length);
        }
    }
    /**
     * 过滤字符串中的省份和“有限公司”，“科技有限公司"，”技术有限公司“，”信息技术有限公司“
     */
    public static  String formatShoppingName(String shoppingName){
    	if(shoppingName.contains("信息")){
    		shoppingName = shoppingName.replace("信息", "");	    			
    	} 
    	if(shoppingName.contains("科技")){
    		shoppingName = shoppingName.replace("科技", "");
    	}
    	if(shoppingName.contains("信息技术有限公司")){
    		shoppingName = shoppingName.replace("信息技术有限公司", "");	    			
    	} 
    	if(shoppingName.contains("技术有限公司")){
    		shoppingName = shoppingName.replace("技术有限公司", "");	    	
    	} 
    	if(shoppingName.contains("有限公司")){
    		shoppingName = shoppingName.replace("有限公司", "");
    	}
    	if(shoppingName.contains("网络")){
    		shoppingName = shoppingName.replace("网络", "");
    	}
    	if(shoppingName.contains("科技发展")){
    		shoppingName = shoppingName.replace("科技发展", "");
    	}
    	if(shoppingName.contains("文化传媒")){
    		shoppingName = shoppingName.replace("文化传媒", "");
    	}
    	
    	return shoppingName;
    }

	@SuppressWarnings("unused")
	public static Object stringNullToZero(Object obj) {
		if (obj == null) {
			return "";
		}
		return obj;
	}

	@SuppressWarnings("unused")
	public static Object floatNullToZero(Object obj) {
		if (obj == null) {
			return 0f;
		}
		return obj;
	}

	@SuppressWarnings("unused")
	public static Object intNullToZero(Object obj) {
		if (obj == null) {
			return 0;
		}
		return obj;
	}
   
}
