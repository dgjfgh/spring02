package com.pampom.mybaties01.mjkutils.util;

import com.pampom.mybaties01.mjkutils.Logger.BizLogger;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.UUID;

public class RandomUtil {
	public static final String allChar = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	public static final String letterChar = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	public static final String numberChar = "0123456789";
	public static String[] chars = new String[] { "a", "b", "c", "d", "e", "f",
			"g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s",
			"t", "u", "v", "w", "x", "y", "z", "0", "1", "2", "3", "4", "5",
			"6", "7", "8", "9", "A", "B", "C", "D", "E", "F", "G", "H", "I",
			"J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V",
			"W", "X", "Y", "Z" };
	
	/**
	 * 获取ComplainNo
	 * @return
	 */
	public static String  generateComplainNo(){
		SimpleDateFormat stf=new SimpleDateFormat("yyyyMMddHHmmss");
		int i=10+(int)(Math.random()*90); 
		String complain_no = "HTK"+stf.format(new Date())+i;
		return complain_no;
	}

	/**
	 * 获取八位UUID
	 * 
	 * @return
	 */
	public static String getShortUuid() {
		StringBuffer shortBuffer = new StringBuffer();
		String uuid = UUID.randomUUID().toString().replace("-", "");
		for (int i = 0; i < 8; i++) {
			String str = uuid.substring(i * 4, i * 4 + 4);
			int x = Integer.parseInt(str, 16);
			shortBuffer.append(chars[x % 0x3E]);
		}
		return shortBuffer.toString();

	}

	/**
	 * 返回一个定长的随机字符串(只包含大小写字母、数字) 　　
	 * 
	 * @param length
	 *            随机字符串长度 　　
	 * @return 随机字符串 　　
	 */
	public static String generateNumber(int length) {
		StringBuffer sb = new StringBuffer();
		Random random = new Random();
		for (int i = 0; i < length; i++) {
			sb.append(numberChar.charAt(random.nextInt(numberChar.length())));
		}
		return sb.toString();
	}

	/**
	 * 返回一个定长的随机字符串(只包含大小写字母、数字) 　　
	 * 
	 * @param length
	 *            随机字符串长度 　　
	 * @return 随机字符串 　　
	 */
	public static String generateString(int length) {
		StringBuffer sb = new StringBuffer();
		Random random = new Random();
		for (int i = 0; i < length; i++) {
			sb.append(allChar.charAt(random.nextInt(allChar.length())));
		}
		return sb.toString();
	}

	/**
	 * 返回一个定长的随机纯字母字符串(只包含大小写字母) 　　
	 * 
	 * @param length
	 *            随机字符串长度 　　
	 * @return 随机字符串 　　
	 */
	public static String generateMixString(int length) {
		StringBuffer sb = new StringBuffer();
		Random random = new Random();
		for (int i = 0; i < length; i++) {
			sb.append(allChar.charAt(random.nextInt(letterChar.length())));
		}
		return sb.toString();
	}

	/**
	 * 返回一个定长的随机纯大写字母字符串(只包含小写字母) 　
	 * 
	 * @param length
	 *            随机字符串长度 　　
	 * @return 随机字符串 　　
	 */
	public static String generateLowerString(int length) {
		return generateMixString(length).toLowerCase();
	}

	/**
	 * 返回一个定长的随机纯小写字母字符串(只包含大写字母) 　　
	 * 
	 * @param length
	 *            随机字符串长度 　　
	 * @return 随机字符串 　　
	 */
	public static String generateUpperString(int length) {
		return generateMixString(length).toUpperCase();
	}

	/**
	 * 生成一个定长的纯0字符串 　　
	 * 
	 * @param length
	 *            字符串长度
	 * @return 纯0字符串 　　
	 */
	public static String generateZeroString(int length) {
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < length; i++) {
			sb.append('0');
		}
		return sb.toString();
	}

	/**
	 * 根据数字生成一个定长的字符串，长度不够前面补0 　　
	 * 
	 * @param num
	 *            数字 　　
	 * @param fixdlenth
	 *            字符串长度 　　
	 * @return 定长的字符串 　　
	 */
	public static String toFixdLengthString(long num, int fixdlenth) {
		StringBuffer sb = new StringBuffer();
		String strNum = String.valueOf(num);
		if (fixdlenth - strNum.length() >= 0) {
			sb.append(generateZeroString(fixdlenth - strNum.length()));
		} else {
			BizLogger.info( new RuntimeException("将数字" + num + "转化为长度为" + fixdlenth
					+ "的字符串发生异常！"));
		}

		sb.append(strNum);
		return sb.toString();
	}

	/**
	 * 根据数字生成一个定长的字符串，长度不够前面补0 　　
	 * 
	 * @param num
	 *            数字 　　
	 * @param fixdlenth
	 *            字符串长度 　　
	 * @return 定长的字符串 　　
	 */
	public static String toFixdLengthString(int num, int fixdlenth) {
		StringBuffer sb = new StringBuffer();
		String strNum = String.valueOf(num);
		if (fixdlenth - strNum.length() >= 0) {
			sb.append(generateZeroString(fixdlenth - strNum.length()));
		} else {
			BizLogger.info( new RuntimeException("将数字" + num + "转化为长度为" + fixdlenth
					+ "的字符串发生异常！"));
		}
		sb.append(strNum);
		return sb.toString();
	}

	/**
	 * 获取随机数 并不重复
	 * 
	 * @param max
	 * @return
	 */
	public static List<String> getRadomArray(int max) {
		List<String> list = new ArrayList<String>();
		max = max + 1;
		boolean[] bol = new boolean[max];
		for (int i = 1; i < max; i++)
			bol[i] = false;
		bol[0] = true;
		for (int i = 0; i < max - 1;) {
			double a = Math.random() * (max - 1);
			a = Math.ceil(a);
			int randomNum = new Double(a).intValue() % max;
			if (bol[randomNum])
				continue;
			bol[randomNum] = true;
			i++;
			list.add(randomNum+"");
		}
		return list;
	}
	/**
	 * 生成[min-max)区间的数
	 * @param min
	 * @param max
	 * @return
	 */
	
	public static int getRadomNum(int min,int max){
		Random random = new Random();
		int s = random.nextInt(max) % (max - min + 1) + min;
		return s;
	}
	public static void main(String[] args) {

		getRadomArray(10);

	}
}
