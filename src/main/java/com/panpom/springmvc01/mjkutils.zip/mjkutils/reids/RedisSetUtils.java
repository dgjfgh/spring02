package com.pampom.mybaties01.mjkutils.reids;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;
import java.util.Set;

import com.pampom.mybaties01.mjkutils.util.StrUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.SetOperations;


public class RedisSetUtils {
	
	public static boolean valueIsExit(RedisTemplate<String, Object> redisTemplate,
			final String key,String value){
		SetOperations<String, Object> setOperations = redisTemplate.opsForSet();
		List<String> keyList = RedisUtils.getKeys(redisTemplate, key);
		for(String tkey : keyList){
			if(setOperations.isMember(tkey, value)){
				return true;				
			}
		}
		return false;
	}
	public static void setCacheSET(RedisTemplate<String, Object> redisTemplate,String key,
			Map<String,Object> map) {
		 //添加 一个 set 集合
        SetOperations<String, Object> set = redisTemplate.opsForSet();
        for(Entry<String, Object> entity : map.entrySet()){
        	if(!StrUtils.isEmpty(entity.getValue()))
        		set.add(key+entity.getKey(), entity.getValue().toString());
        }		
	}
//	public static void setCacheSET(RedisTemplate<String, Object> redisTemplate,
//			final String key, final Map<String, Map<String, Object>> map) {
//		
//		SetOperations<String, Object> setOperations = redisTemplate.opsForSet();
//		redisTemplate.execute(new RedisCallback<Integer>() {
//			@Override
//			public Integer doInRedis(RedisConnection connection)
//					throws DataAccessException {
//				connection.openPipeline();
//				for (Entry<String, Map<String, Object>> entity : map.entrySet()) {
//					if (!StrUtils.isEmpty(entity.getValue())) {
//						for (Entry<String, Object> entry1 : entity.getValue()
//								.entrySet()) {
//							if (StrUtils.isNotEmpty(entry1.getValue())) {
//								connection.sAdd((key + entry1.getKey()), (entry1
//										.getValue().toString() + "=" + entity
//										.getKey()));
//							}
//						}
//					}
//				}
//				connection.closePipeline();
//				return 0;
//			}
//		});
//	}

	public static void setCacheSET(RedisTemplate<String, Object> redisTemplate,
			final String key, String value,long time) {
		SetOperations<String, Object> setOperations = redisTemplate.opsForSet();
		setOperations.add(key, value);
		//2天过期
		if(time > 0)
			redisTemplate.expire(key, time, TimeUnit.SECONDS);
	}

	public static void updateCacheSET(
			RedisTemplate<String, Object> redisTemplate, final String key,
			final Map<String, String> map) {
		// 添加 一个 set 集合
		// SetOperations<String, Object> set = redisTemplate.opsForSet();
		redisTemplate.execute(new RedisCallback<Integer>() {
			@Override
			public Integer doInRedis(RedisConnection connection)
					throws DataAccessException {
				connection.openPipeline();
				for (Entry<String, String> entity : map.entrySet()) {
					if (!StrUtils.isEmpty(entity.getValue())) {
						connection.sRem(key.getBytes(), entity.getKey()
								.getBytes());
						connection.sAdd(key.getBytes(), entity.getValue()
								.toString().getBytes());
						// set.remove(key, entity.getKey());
						// set.add(key, entity.getValue().toString());
					}
				}
				connection.closePipeline();
				return 0;
			}
		});
	}

	public static Set<Object> getCacheSET(
			RedisTemplate<String, Object> redisTemplate, String key) {
		SetOperations<String, Object> setOperations = redisTemplate.opsForSet();
		Set<Object> set = setOperations.members(key);
		return set;
	}

	public static void removeCacheSET(
			RedisTemplate<String, Object> redisTemplate, String key) {
		// SetOperations<String, Object> setOperations =
		// redisTemplate.opsForSet();
		redisTemplate.delete(key);
	}
}
