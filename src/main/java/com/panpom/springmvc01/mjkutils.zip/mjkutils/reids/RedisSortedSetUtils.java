package com.pampom.mybaties01.mjkutils.reids;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.pampom.mybaties01.mjkutils.util.NumberUtils;
import com.pampom.mybaties01.mjkutils.util.StrUtils;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.core.RedisCallback;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.data.redis.core.ZSetOperations.TypedTuple;


public class RedisSortedSetUtils {

	public static void setCacheSortedSet(
			RedisTemplate<String, Object> redisTemplate, String key,
			Map<String,Integer> map) {		
		ZSetOperations<String, Object> zset = redisTemplate.opsForZSet();
		for(Entry<String, Integer> entry : map.entrySet()){
			zset.add(key, entry.getKey(), entry.getValue());
		}		
	}
	
	/**
	 * 存储sortedset
	 * @param redisTemplate
	 * @param key
	 * @param map
	 * @param sorce
	 */
	public static void setCacheSortedSet(
			RedisTemplate<String, Object> redisTemplate, final String key,
			final Map<String,Object> map,final String sorce) {		
//		ZSetOperations<String, Object> zset = redisTemplate.opsForZSet();
		redisTemplate.execute(new RedisCallback<Integer>() {
			@Override
			public Integer doInRedis(RedisConnection connection)
					throws DataAccessException {	
				connection.openPipeline();
				for(Entry<String, Object> entry : map.entrySet()){
					if(StrUtils.isNotEmpty(entry.getValue()))
						connection.zAdd((key+entry.getKey()).getBytes(), NumberUtils.doubleValue(sorce),
								(entry.getValue().toString()+"="+sorce).getBytes());
				}
				connection.closePipeline();
				return 0;
			}
		});
				
	}
	/**
	 * 根据值获取分数
	 * @param redisTemplate
	 * @param key
	 * @param value
	 * @return
	 */
	public static Integer getCacheSortedSetScore(
			RedisTemplate<String, Object> redisTemplate, String key,String value) {
		ZSetOperations<String, Object> zset = redisTemplate.opsForZSet();
		Double index = zset.score(key, value);
		return index.intValue();
	}
	/**
	 * 根据分数获取值
	 * @param redisTemplate
	 * @param key
	 * @param index
	 * @return
	 */
	public static String getCacheSortedSetValue(
			RedisTemplate<String, Object> redisTemplate,String key, String index) {
		ZSetOperations<String, Object> zset = redisTemplate.opsForZSet();
		Set<Object> set = zset.rangeByScore(key, NumberUtils.doubleValue(index),  NumberUtils.doubleValue(index));
		if(set!=null && set.size()>0){
			return set.toArray()[0].toString();
		}
		return null;		
	}
	/**
	 * 获取Key中的值，带值和分数
	 * @param redisTemplate
	 * @param key
	 * @return
	 */
	public static Map<String,Integer> getCacheAllValue(RedisTemplate<String, Object> redisTemplate,String key){
		ZSetOperations<String, Object> zset = redisTemplate.opsForZSet();
		Set<TypedTuple<Object>> set = zset.rangeWithScores(key, 0, -1);
		Map<String,Integer> map = new HashMap<String,Integer>();
		for(TypedTuple o : set){
			map.put(o.getValue().toString(), o.getScore().intValue());
		}
		return map;
	}
	/**
	 * 
	 * @param redisTemplate
	 * @param key
	 * @param value
	 */
	public static void delSortedSetValue(RedisTemplate<String, Object> redisTemplate,String key,String value){
		ZSetOperations<String, Object> zset = redisTemplate.opsForZSet();
		zset.remove(key, value);
	}
}
