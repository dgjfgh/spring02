package com.pampom.mybaties01.mjkutils.jms;

public class JmsConsts {
	/**
	 * 队列名称
	 * @author jafe
	 * @date 2017年8月24日
	 */
	public static class JmsDestination{
		/**
		 * 回调
		 */
		public static final String CALLBACK_QUERY_NAME = "paycallbackQuery";
		/**
		 * 失败时给下游回调
		 */
		public static final String CALLBACK_USER = "paycalluserback";
		/**
		 * 提单
		 */
		public static final String RECHARGE_QUERY_NAME = "payrechargeQuery";
		/**
		 * 同步数据
		 */
		public static final String SYN_REDIS_TO_MYSQL="payredis2mysql";
		/**
		 * 同步数据
		 */
		public static final String SYN_MYSQL_TO_REDIS="paymysql2redis";		
	}
	public static class SYN_TYPE{
		public static final int SYN_SAVE = 1;		
		public static final int SYN_UPDATE = 2;
		public static final int SYN_SAVE_LIST = 3;
		public static final int SYN_UPDATE_LIST = 4;
		public static final int SYN_DELET = 5;
		public static final int SYN_DELET_LIST = 6;
		public static final int SYN_SAVE_OR_UPDATE = 7;
	}
}
