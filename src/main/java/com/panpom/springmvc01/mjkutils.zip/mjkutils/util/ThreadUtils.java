package com.pampom.mybaties01.mjkutils.util;

import com.pampom.mybaties01.mjkutils.Logger.BizLogger;

public class ThreadUtils {
	public static void sleep(int time){
		try {
			Thread.sleep(time);
		} catch (InterruptedException e) {
			throw BizLogger.info(e);
		}
	}
}
