package com.pampom.mybaties01.mjkutils.Logger;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * log
 * 
 * @author jafe
 * @date 2017年10月25日
 */
public class BizLogger {
	public static Logger log = LoggerFactory.getLogger(BizLogger.class);
	
	/**
	 * 打印警告
	 * @param obj
	 */
	public static RuntimeException warn(Object obj) {		
		/*** 获取输出信息的代码的位置 ***/
		String location = "";
		StackTraceElement[] stacks = Thread.currentThread().getStackTrace();
		location = stacks[2].getClassName() + "."
				+ stacks[2].getMethodName() + "-["
				+ stacks[2].getLineNumber() + "]";
		/*** 是否是异常 ***/
		if (obj instanceof Exception) {				
			log.warn(location , obj);
			if(obj instanceof RuntimeException)
				return (RuntimeException)obj;
		} else {
			log.warn(location , obj);
		}		
		return null;
	}

	/**
	 * 打印信息
	 * 
	 * @param obj
	 */
	public static RuntimeException info(Object obj) {		
		/*** 获取输出信息的代码的位置 ***/
		String location = "";
		StackTraceElement[] stacks = Thread.currentThread().getStackTrace();
		location = stacks[2].getClassName() + "."
				+ stacks[2].getMethodName() + "-["
				+ stacks[2].getLineNumber() + "]";
		/*** 是否是异常 ***/
		if (obj instanceof Exception) {				
			log.info(location , obj);
			if(obj instanceof RuntimeException)
				return (RuntimeException)obj;
		} else {
			log.info(location+obj.toString());
		}		
		return null;
	}
	
	/**
	 * 打印信息
	 * 
	 * @param obj
	 */
	public static RuntimeException info(String tilte,Object obj) {
		/*** 获取输出信息的代码的位置 ***/
		String location = "";
		StackTraceElement[] stacks = Thread.currentThread().getStackTrace();
		location = stacks[2].getClassName() + "."
				+ stacks[2].getMethodName() + "-["
				+ stacks[2].getLineNumber() + "]";
		/*** 是否是异常 ***/
		if (obj instanceof Exception) {				
			log.info(tilte+location ,obj);
			if(obj instanceof RuntimeException)
				return  (RuntimeException)obj;
		} else {
			log.info(location+tilte+obj.toString());
		}
		return null;
	}

	/**
	 * 打印错误
	 * 
	 * @param obj
	 */
	public static RuntimeException error(Object obj) {
	
		/*** 获取输出信息的代码的位置 ***/
		String location = "";
		StackTraceElement[] stacks = Thread.currentThread().getStackTrace();
		location = stacks[2].getClassName() + "."
				+ stacks[2].getMethodName() + "-["
				+ stacks[2].getLineNumber() + "]";

		/*** 是否是异常 ***/
		if (obj instanceof Exception) {				
			log.error(location , obj);
			if(obj instanceof RuntimeException)
				return (RuntimeException)obj;
		} else {
			log.error(location+obj.toString());
		}
		return null;
	}
	/**
	 * 打印错误
	 * 
	 * @param obj
	 */
	public static RuntimeException error(String title,Object obj) {
		/*** 获取输出信息的代码的位置 ***/
		String location = "";
		StackTraceElement[] stacks = Thread.currentThread().getStackTrace();
		location = stacks[2].getClassName() + "."
				+ stacks[2].getMethodName() + "-["
				+ stacks[2].getLineNumber() + "]";
		/*** 是否是异常 ***/
		if (obj instanceof Exception) {				
			log.error(title+location,obj);
			if(obj instanceof RuntimeException)
				return (RuntimeException)obj;
		} else {
			log.error(title+location, obj);
		}
		return null;
	}
}
