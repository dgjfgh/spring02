//package com.pampom.mybaties01.common.jms;
//
//import javax.jms.JMSException;
//import javax.jms.Message;
//import javax.jms.Session;
//import javax.jms.TextMessage;
//
//import org.apache.activemq.ScheduledMessage;
//import org.springframework.jms.core.JmsTemplate;
//import org.springframework.jms.core.MessageCreator;
//
//
//public class JmsSender {
//	/**
//	 * 发送jms消息倒队列
//	 * @param jmsQueueTemplate
//	 * @param msg
//	 * @param destinationName
//	 */
//	public static void sendJmsMsg(JmsTemplate jmsQueueTemplate,final String msg,String destinationName) {
//		jmsQueueTemplate.send(destinationName, new MessageCreator() {
//			public Message createMessage(Session session) throws JMSException {
//				 TextMessage message = session.createTextMessage(msg);
//				 return message;
//			}
//		});
//	}
//
//	/**
//	 * 发送延时消息
//	 * @param jmsQueueTemplate
//	 * @param msg
//	 * @param destinationName
//	 * @param time
//	 */
//	public static void sendDelayMsg(JmsTemplate jmsQueueTemplate,final String msg,String destinationName,final long time){
//		jmsQueueTemplate.send(destinationName, new MessageCreator() {
//			public Message createMessage(Session session) throws JMSException {
//				 TextMessage message = session.createTextMessage(msg);
//			     message.setLongProperty(ScheduledMessage.AMQ_SCHEDULED_DELAY, time);
//                 return message;
//			}
//		});
//	}
//}
