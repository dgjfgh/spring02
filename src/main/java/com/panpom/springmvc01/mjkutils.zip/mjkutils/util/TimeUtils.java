package com.pampom.mybaties01.mjkutils.util;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * 时间工具
 * 
 * @author Administrator
 * 
 */
public class TimeUtils {
	//时间格式定义
	public static String DATE_FORMAT_DATEONLY = "yyyy-MM-dd"; // 年/月/日
	public static String DATE_FORMAT_DATETIME = "yyyy-MM-dd HH:mm:ss"; // 年/月/日
	public static String DATE_FORMAT_DATETIME_SHORT = "yyyyMMddHHmmss"; // 年/月/日
	public static SimpleDateFormat sdfDateTime = new SimpleDateFormat(DATE_FORMAT_DATETIME);	
	public static SimpleDateFormat sdfDateOnly = new SimpleDateFormat(DATE_FORMAT_DATEONLY);
	public static SimpleDateFormat sdfDateTimeShort = new SimpleDateFormat(DATE_FORMAT_DATETIME_SHORT);
	public static final SimpleDateFormat SHORTDATEFORMAT = new SimpleDateFormat("yyyyMMdd");
	public static final SimpleDateFormat SHORT_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
	public static final SimpleDateFormat LONGDATEFORMAT = new SimpleDateFormat("yyyyMMddHHmmssSSS");
	public static final SimpleDateFormat LONG_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	public static final SimpleDateFormat HMS_FORMAT = new SimpleDateFormat("HH:mm:ss");
	public static final SimpleDateFormat formatTimestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	
	public static final SimpleDateFormat SHORTDATEFORMAT_BS = new SimpleDateFormat("yyyy/MM/dd");
	
	public static final SimpleDateFormat LONGDATEFORMAT_BS = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
	
	public static String startDayTime = " 00:00:00";
	public static String endDayTime = " 23:59:59";
	
	public static class TimeSearch{
		public static final String START_TIME = "start";
		public static final String END_TIME = "end";
	}
	
	public static int getDayOfMonth() {
		Calendar c = Calendar.getInstance();
		return c.get(Calendar.DAY_OF_MONTH);
	}
	/**
	 * 获取某天的开始时间
	 * @param date
	 * @return
	 */
	public static Date getDayStart(Date date){
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
	    calendar.set(Calendar.HOUR_OF_DAY, 0);
	    calendar.set(Calendar.MINUTE, 0);
	    calendar.set(Calendar.SECOND, 0);
	     
	    Date start = calendar.getTime();
	    return start;
	}
	
	/**
	 * 获取某天的结束时间
	 * @param date
	 * @return
	 */
	public static Date getDayEnd(Date date){		
		Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
	    calendar.set(Calendar.HOUR_OF_DAY, 0);
	    calendar.set(Calendar.MINUTE, 0);
	    calendar.set(Calendar.SECOND, 0);	     	    
	    calendar.add(Calendar.DAY_OF_MONTH, 1);
	    calendar.add(Calendar.SECOND, -1);
	     
	    Date end = calendar.getTime();
	    return end;
	}
	/**
	 * 昨天到今天的
	 */
	public static Map<String,Date> getBetiwnTommoryDay(int day) {
		Map<String,Date> map = new HashMap<String,Date>();
		Calendar c = Calendar.getInstance();
		int MaxDay = c.getActualMaximum(Calendar.DAY_OF_MONTH);
		if (day > MaxDay) {// 如果超出最大天数报错
			return null;
		}
		c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), day - 1, 0, 0, 0);
		map.put(TimeSearch.START_TIME, new Date(c.getTimeInMillis()));		
		c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), day + 1, 0, 0, 0);
		map.put(TimeSearch.END_TIME, new Date(c.getTimeInMillis()));
		return map;
	}

	/**
	 * 今天开始，到明天结束
	 * @param day
	 * @return
	 */
	public static Map<String,Date> getBetweenDay(int day) {
		Map<String,Date> map = new HashMap<String,Date>();
		Calendar c = Calendar.getInstance();
		int MaxDay = c.getActualMaximum(Calendar.DAY_OF_MONTH);
		if (day > MaxDay) {// 如果超出最大天数报错
			return null;
		}
		c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), day, 0, 0, 0);
		map.put(TimeSearch.START_TIME, new Date(c.getTimeInMillis()));	
		c.set(c.get(Calendar.YEAR), c.get(Calendar.MONTH), day + 1, 0, 0, 0);
		map.put(TimeSearch.END_TIME, new Date(c.getTimeInMillis()));
		return map;
	}

	/**
	 * 得到本周周一
	 * 
	 * @return yyyy-MM-dd
	 */
	public static String getMondayOfThisWeek() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		int day_of_week = c.get(Calendar.DAY_OF_WEEK) - 1;
		if (day_of_week == 0)
			day_of_week = 7;
		c.add(Calendar.DATE, -day_of_week + 1);
		return sdf.format(c.getTime());
	}

	/**
	 * 得到本周周日
	 * 
	 * @return yyyy-MM-dd
	 */
	public static String getSundayOfThisWeek() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		int day_of_week = c.get(Calendar.DAY_OF_WEEK) - 1;
		if (day_of_week == 0)
			day_of_week = 7;
		c.add(Calendar.DATE, -day_of_week + 7);
		return sdf.format(c.getTime());
	}

	/**
	 * 获取本月第一天
	 */
	public static String getFristDayOfMonth() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		c.add(Calendar.MONTH, 0);
		c.set(Calendar.DAY_OF_MONTH, 1);// 设置为1号,当前日期既为本月第一天
		return sdf.format(c.getTime());
		// System.out.println("===============first:"+first);
	}

	/**
	 * 获取本月最后一天
	 */
	public static String getLastDayOfMonth() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar ca = Calendar.getInstance();
		ca.set(Calendar.DAY_OF_MONTH,
				ca.getActualMaximum(Calendar.DAY_OF_MONTH));

		return sdf.format(ca.getTime());
		// System.out.println("===============first:"+first);
	}

	/**
	 * 获取三个月前的日期
	 */
	public static String getThridMoneyBeforDay() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String defaultStartDate = "";
		Calendar ca = Calendar.getInstance();
		try {
			ca.setTime(sdf.parse(getLastDayOfMonth()));
			ca.add(ca.MONTH, -3); // 设置为前3月
			Date dBefore = ca.getTime(); // 得到前3月的时间
			defaultStartDate = sdf.format(dBefore); // 格式化前3月的时间
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return defaultStartDate;
	}

	/**
	 * 计算明天的日期
	 */
	public static Timestamp getTomDay() {
		
		return getAfterDay(1);

	}
	
	/**
	 * 计算延后几天的日期
	 */
	public static Timestamp getAfterDay(int day) {
		Calendar calendar = Calendar.getInstance();

		calendar.add(calendar.DATE, day);// 把日期往后增加一天.整数往后推,负数往前移动
		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		return new Timestamp(calendar.getTimeInMillis());

	}
	/**
	 * 
	 * @param day
	 * @return
	 */
	public static String getAfterDay(int day,String startTime) {		
		Calendar calendar = Calendar.getInstance();
		try {
			calendar.setTime(SHORTDATEFORMAT.parse(startTime));
			calendar.add(calendar.DATE, day);// 把日期往后增加一天.整数往后推,负数往前移动
			calendar.set(Calendar.HOUR, 0);
			calendar.set(Calendar.MINUTE, 0);
			calendar.set(Calendar.SECOND, 0);
			return SHORTDATEFORMAT.format(new Date(calendar.getTimeInMillis()));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return "";

	}

	/**
	 * 计算下个月的开始日期
	 */
	public static Timestamp getNextMonth() {
		Calendar calendar = Calendar.getInstance();

		calendar.add(calendar.MONTH, 1);// 把日期往后增加一天.整数往后推,负数往前移动
		calendar.set(Calendar.HOUR, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		return new Timestamp(calendar.getTimeInMillis());

	}

	/**
	 * 计算两个时间戳是不是在同一天
	 */
	public static int isSameDay(long nowTime, long buildTime) {

		Calendar cal1 = Calendar.getInstance();
		cal1.setTimeInMillis(nowTime);

		Calendar cal2 = Calendar.getInstance();
		cal2.setTimeInMillis(buildTime);

		boolean isSameYear = cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);
		boolean isSameMonth = isSameYear
				&& cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH);
		boolean isSameDate = isSameMonth
				&& cal1.get(Calendar.DAY_OF_MONTH) == cal2
						.get(Calendar.DAY_OF_MONTH);
		// 如果不 在 同一天
		if (isSameDate) {
			return 0;
		} else {
			int day1 = cal1.get(Calendar.DAY_OF_YEAR);
			int day2 = cal2.get(Calendar.DAY_OF_YEAR);

			int year1 = cal1.get(Calendar.YEAR);
			int year2 = cal2.get(Calendar.YEAR);
			if (year1 != year2) // 同一年
			{
				int timeDistance = 0;
				for (int i = year1; i < year2; i++) {
					if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0) // 闰年
					{
						timeDistance += 366;
					} else // 不是闰年
					{
						timeDistance += 365;
					}
				}

				return timeDistance + (day1 - day2);
			} else // 不同年
			{
				
				return day1 - day2;
			}
		}

	}

	public static boolean isBetweenTime(long startTime, long endTime,
			long nowTime) {
		if (startTime == 0 && endTime == 0) {
			return false;
		} else if (startTime != 0 && endTime == 0) {
			if (nowTime >= startTime) {
				return true;
			}
		} else if (startTime == 0 && endTime != 0) {
			if (nowTime <= endTime) {
				return true;
			}
		} else {
			if (nowTime >= startTime && nowTime <= endTime) {
				return true;
			}
		}
		return false;
	}
	
	public static Date parse(SimpleDateFormat formate,String str) {
		try {
			return formate.parse(str);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return new Date();
	}
	/**
	 * 英文改为中文时间
	 * @param str
	 * @return
	 */
	public static Date parse(String str) {
		Date date = null ;
		if (str == null ) {
			return null;
		}
		try {
			date =  new SimpleDateFormat("EEE MMM dd HH:mm:ss zzz yyyy", Locale.US).parse(str);
		} catch (Exception e) {
			
		}
		if(date == null){
			try {
				if(str.contains("-")&&str.contains(":")){
					date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(str);
				}else{
					date = new SimpleDateFormat("yyyy-MM-dd").parse(str);
				}
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return date;
	}
}
